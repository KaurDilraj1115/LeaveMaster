package com.example.Leavemasters;

import java.util.Calendar;
import android.os.Bundle;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.app.ActionBar.LayoutParams;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class CreditActivity1 extends Activity implements OnItemSelectedListener 
{
	ListView listView;
	TableLayout record_table;
	TableRow row,tr;
	ProgressDialog pdialog;
    TextView t1, t2,t3,t4,t5,t6;
	String res;
	ImageButton editrow,addrows,deleterow,ib;
    String crlist;
	String ename,ecode,ctytpe,cl,pl,cdate,others;
    EditText epcode, eptytpe,epcl,eppl,epdate,epothers;
    String s,date,s1,s2,s3,s4,s5,s6,s7,str;
	Spinner spinnerDropDown;
     private Calendar cal;
	 private int day;
	 private int month;
	 private int year;
	 private EditText et;
	 String empcode11;
	 String s11,q1,q2;
	 @Override
   protected void onCreate(Bundle savedInstanceState) {
   super.onCreate(savedInstanceState);
   setContentView(R.layout.mainnew);
   new emplist().execute();
		    ib = (ImageButton) findViewById(R.id.imageButton1);
		    cal = Calendar.getInstance();
		    day = cal.get(Calendar.DAY_OF_MONTH);
		    month = cal.get(Calendar.MONTH);
		    year = cal.get(Calendar.YEAR);
		    et = (EditText) findViewById(R.id.editText);
		    record_table=(TableLayout)findViewById(R.id.record_table);
		    new emplist().execute();
		   
		    SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE); 
			q1=   pref.getString("username", null);         
		    q2=    pref.getString("usertype", null);
		    Log.i("TAG","emp" +q1+q2);
		
       ib.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				showDialog(0);
				}
			});
          editrow=(ImageButton)findViewById(R.id.edit);
	      addrows=(ImageButton)findViewById(R.id.addrow);
	      deleterow=(ImageButton)findViewById(R.id.delete);
	  	  epdate=(EditText)findViewById(R.id.tv_13);
		  epcl=(EditText)findViewById(R.id.tv_14);
		  eppl=(EditText)findViewById(R.id.tv_15);
		  epothers=(EditText)findViewById(R.id.tv_16);
		  epcode=(EditText)findViewById(R.id.tv_12);
		  eptytpe=(EditText)findViewById(R.id.tv_17);
		 List<String> elist=new ArrayList<String>();
         
	      editrow.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				s1=epcode.getText().toString();
				s2=epdate.getText().toString();
				s3=eptytpe.getText().toString();
				s4=epcl.getText().toString();
				s5=eppl.getText().toString();
				s6=epothers.getText().toString();
				s7="0";
				new editrows().execute();
				
			}
		});
	      addrows.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				new addrows().execute();
			}
		});
	  
}
	private void choosedate() {
		// TODO Auto-generated method stub
		
	}
	private void choosedateandcode() {
		// TODO Auto-generated method stub

		}
//	
  public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
		 {
		 
    }
	
		 public void onNothingSelected(AdapterView<?> parent)
		 {
		 // TODO Auto-generated method stub 
		
		 }
		 @Override
		 protected Dialog onCreateDialog(int id) {
		  return new DatePickerDialog(this, datePickerListener, year, month, day);
		 }
          private DatePickerDialog.OnDateSetListener datePickerListener = new DatePickerDialog.OnDateSetListener() {
		  public void onDateSet(DatePicker view, int selectedYear,int selectedMonth, int selectedDay) 
		  {
		   et.setText((selectedMonth + 1)+ " / " +  +selectedDay + " / " + selectedYear);

		}
		};
		 private void record_table() {
				// TODO Auto-generated method stub
				}
	
		
		 public class emplist extends AsyncTask<Void, Void, Void>
		 {
			 
				List<String> emlist=new ArrayList<String>();
				
				
			  @Override
				protected void onPreExecute() {
					// TODO Auto-generated method stub

			      super.onPreExecute();
				  }
              @Override
			protected Void doInBackground(Void... arg0) {
				// TODO Auto-generated method stub
            	  Log.i("TAG","usetype" +q1+q2);
				JSONObject j1 = new JSONObject();
	  			ServiceHandler sh = new ServiceHandler();
	  			String url = "http://javat.drishinfo.com/LeaveProject-war/MyService";
	  			List<NameValuePair> nameValuePairsList = new ArrayList<NameValuePair>();
				nameValuePairsList.add(new BasicNameValuePair("operation","Emplist"));
				nameValuePairsList.add(new BasicNameValuePair("empcode",q1));
				nameValuePairsList.add(new BasicNameValuePair("usertype",q2));
				 res = sh.makeServiceCall(url, ServiceHandler.GET,nameValuePairsList);
				  Log.i("TAG", res);
				return null;
			}
			@Override
			protected void onPostExecute(Void result) 
		{
			// TODO Auto-generated method stub

				 Log.i("TAG","usetype2" +q1+q2);
			super.onPostExecute(result);
			 try {
				JSONObject j3 =  new  JSONObject(res);
				JSONArray jarray=j3.getJSONArray("emplist");
				
				for(int i=0;i<jarray.length();i++)
				{
					Log.i("TAG", "list");

					
			     emlist.add(jarray.getString(i));   
				}
					 spinnerDropDown =(Spinner)findViewById(R.id.spinner1);
				
ArrayAdapter<String> adapter = new ArrayAdapter<String>(CreditActivity1.this,android.R.layout.simple_spinner_item, emlist);
	adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	  spinnerDropDown.setAdapter(adapter);
	  spinnerDropDown.setOnItemSelectedListener(new OnItemSelectedListener() {

		@Override
		public void onItemSelected(AdapterView<?> arg0, View arg1, int position,
				long arg3) {
			// TODO Auto-generated method stub
		      str=spinnerDropDown.getSelectedItem().toString();
			  s11=et.getText().toString();
			
			 if(str.length()>0&&s11.length()>0)
			 {
				 Log.i("TAG", "position"+position);
			 new EmplistTask().execute(str);
			 }
			 else
			 {
				 Toast.makeText(CreditActivity1.this, "plz fill date and empcode",Toast.LENGTH_LONG).show();
			 }		
			
		}

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			// TODO Auto-generated method stub
			
		}
	});
					
				}
		 catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		} 
			 }
		 public  class EmplistTask extends AsyncTask<String, String, String>
		 {
		 
	   @Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			pdialog = new ProgressDialog(CreditActivity1.this);
			pdialog.setMessage("Please wait...");
			pdialog.setCancelable(false);
			pdialog.show();
	      super.onPreExecute();
		  }

		@Override
	  		protected String doInBackground(String... params) {
	  			// TODO Auto-generated method stub 
	  			JSONObject jobj = new JSONObject();
	  			
	  			Log.i("TAG", "***"+params[0]);
	  			String empcode11=params[0];
	  			ServiceHandler sh = new ServiceHandler();
	  			String url = "http://javat.drishinfo.com/LeaveProject-war/MyService";
	  			try {
	  				
					List<NameValuePair> nameValuePairsList = new ArrayList<NameValuePair>();
					nameValuePairsList.add(new BasicNameValuePair("operation","crlist"));
					Log.i("TAG", "@@@@@@"+params[0]+"****"+s11);
					nameValuePairsList.add(new BasicNameValuePair("empcode",params[0]));
				   nameValuePairsList.add(new BasicNameValuePair("cdate",s11.replaceAll("\\s","")));
			      res = sh.makeServiceCall(url, ServiceHandler.GET,nameValuePairsList);
					  Log.i("TAG", res);
				} 
	  			catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
	  	return null;
	  		}

	 
		
		@Override
			protected void onPostExecute(String result) 
		{
			// TODO Auto-generated method stub
			if (pdialog.isShowing())
				pdialog.dismiss();
			super.onPostExecute(result);
			 try {
				JSONObject jobj2 =  new  JSONObject(res);
				JSONArray jarray=jobj2.getJSONArray("creditlist");
				record_table.removeAllViews();
				for(int i=0;i<jarray.length();i++)
				{
					Log.i("TAG", "list");
					JSONObject jobj3=jarray.getJSONObject(i);
					 ctytpe=jobj3.getString("ctytpe");
					 cl=jobj3.getString("cl");
					 pl=jobj3.getString("pl");
					 cdate=jobj3.getString("cdate");
					 ecode=jobj3.getString("ecode");
					 others=jobj3.getString("others");
				record_table(cdate,cl,pl,others,ecode, ctytpe);
					}
				}
		 catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}


				}

	private void record_table(String cdate,String cl,String pl,String others,String ecode,String ctytpe) 
	{
		
	// TODO Auto-generated method stub

	 int dip = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, (float) 1, getResources().getDisplayMetrics());
	            row = new TableRow(CreditActivity1.this);
	            t1 = new TextView(CreditActivity1.this);
	            t2 = new TextView(CreditActivity1.this);
	            t3=new TextView(CreditActivity1.this);
	            t4=new TextView(CreditActivity1.this);
	            t5=new TextView(CreditActivity1.this);
	            t6=new TextView(CreditActivity1.this);

	            t1.setText(ecode);
	            t2.setText(cdate);
	            t3.setText(cl);
	            t4.setText(pl);
	            t5.setText(others);
	           t6.setText(ctytpe);
	          
	            t1.setTypeface(null, 1);
	            t2.setTypeface(null, 1);
	            t3.setTypeface(null, 1);
	            t4.setTypeface(null, 1);
	            t5.setTypeface(null, 1);
	            t6.setTypeface(null, 1);
	         
	            t1.setTextSize(15);
	            t2.setTextSize(15);
	            t3.setTextSize(15);
	            t4.setTextSize(15);
	            t5.setTextSize(15);
	            t6.setTextSize(15);

	            t1.setWidth(60*dip);
	            t1.setHeight(30*dip);
	            t2.setWidth(80*dip);
	            t2.setHeight(30*dip);
	            t3.setWidth(60*dip);
	            t3.setHeight(30* dip);
	            t4.setWidth(60*dip);
	            t4.setHeight(30*dip);
	            t5.setWidth(60*dip);
	            t5.setHeight(30*dip);
	            t6.setWidth(70*dip);
	            t6.setHeight(30*dip);
	            
	            row.addView(t1);
	            row.addView(t2);
	            row.addView(t3);
	            row.addView(t4);
	            row.addView(t5);
	            row.addView(t6);
	           record_table.addView(row);
	 
		 row.setOnClickListener(new OnClickListener() {
				 @Override
				 public void onClick(View v) {
				 // TODO Auto-generated method stub
				 TableRow t = (TableRow) v;
				      TextView firstTextView = (TextView) t.getChildAt(0);
				      TextView secondTextView = (TextView) t.getChildAt(1);
				      TextView thirdTextView = (TextView) t.getChildAt(2);
				      TextView fourthTextView = (TextView) t.getChildAt(3);
				      TextView fifthTextView = (TextView) t.getChildAt(4);
				      TextView sixthTextView = (TextView) t.getChildAt(5);
				      String firstText = firstTextView.getText().toString();
				      String secondText = secondTextView.getText().toString();
				      String thirdText = thirdTextView.getText().toString();
				      String fourthText = fourthTextView.getText().toString();
				      String fifthText = fifthTextView.getText().toString();
				      String sixthText = sixthTextView.getText().toString();
				      Log.i("TAG", "******"+firstText+"%%%%%%"+secondText);

				      epdate.setText(firstText);
				      epcl.setText(secondText);
				      eppl.setText(thirdText);
				      epothers.setText(fourthText);
				      epcode.setText(fifthText);
				      eptytpe.setText(sixthText);
				      
				 }
				 });
}
		
		public class editrows extends AsyncTask<Void,Void,Void>
		{
			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				pdialog = new ProgressDialog(CreditActivity1.this);
				pdialog.setMessage("Please wait...");
				pdialog.setCancelable(false);
				pdialog.show();
	           super.onPreExecute();
			}

			@Override
			protected Void doInBackground(Void...params) {
				// TODO Auto-generated method stub
				String url = "http://javat.drishinfo.com/LeaveProject-war/MyService";
				ServiceHandler sh = new ServiceHandler();
			    JSONObject jobj1 = new JSONObject();
			try {
				jobj1.put("empcode", s1);
				jobj1.put("creditdate", s2);
				jobj1.put("credittype", s3);
				jobj1.put("clsl", s4);
				jobj1.put("pl", s5);
				jobj1.put("others", s6);
				jobj1.put("comp",s7);
				Log.i("TAG", "***"+jobj1.toString());
			  List<NameValuePair> nameValuePairsList = new ArrayList<NameValuePair>();			
			nameValuePairsList.add(new BasicNameValuePair("operation","cedit"));
			nameValuePairsList.add(new BasicNameValuePair("ceditStr", jobj1.toString()));
		    res = sh.makeServiceCall(url, ServiceHandler.GET,nameValuePairsList);
		   Log.i("TAG", "res"+res);
							} 
			catch (JSONException e) {
		// TODO Auto-generated catch block
			e.printStackTrace();
					}
			return null;
			}
			@Override
			protected void onPostExecute(Void result) 
			{
				// TODO Auto-generated method stub
				if (pdialog.isShowing())
					pdialog.dismiss();
				
				try {
					JSONObject jobj2;
					jobj2 = new JSONObject(res);
					String s1= jobj2.getString("result");
					Log.i("TAG","drishhhhhhhhh"+s1);
             if(s1.equals("true"))
					{
				Toast.makeText(CreditActivity1.this,"edited suceful",Toast.LENGTH_LONG ).show();
				restartFirstActivity();
							}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            super.onPostExecute(result);
			}

		 }
		
public class addrows extends AsyncTask<Void,Void,Void>
		 {
			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				pdialog = new ProgressDialog(CreditActivity1.this);
				pdialog.setMessage("Please wait...");
				pdialog.setCancelable(false);
				pdialog.show();
	           super.onPreExecute();
			}
            @Override
			protected Void doInBackground(Void... arg0) {
				// TODO Auto-generated method stub
				String url= "http://javat.drishinfo.com/LeaveProject-war/MyService";
				ServiceHandler sh = new ServiceHandler();	
				JSONObject obj=new JSONObject();
			try {
					obj.put("ctype", eptytpe.getText().toString());
					obj.put("ecode", epcode.getText().toString());
					obj.put("others", epothers.getText().toString());
					obj.put("cl",  epcl.getText().toString());
					obj.put("pl", eppl.getText().toString());
					obj.put("cdate",epdate.getText().toString());
					obj.put("comp", "0");
					
					List<NameValuePair> nameValuePairsList = new ArrayList<NameValuePair>();			
					nameValuePairsList.add(new BasicNameValuePair("operation","registercredit"));
					nameValuePairsList.add(new BasicNameValuePair("registercreditStr", obj.toString()));
					res = sh.makeServiceCall(url, ServiceHandler.GET,nameValuePairsList);
					Log.i("tag","resadd"+res);
					
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				return null;
			}
			@Override
			protected void onPostExecute(Void result) 
			{
				// TODO Auto-generated method stub
				if (pdialog.isShowing())
					pdialog.dismiss();
		try {
						JSONObject jobj=new JSONObject(res);
						String s1= jobj.getString("result");
			            Log.i("Tag", "*******"+"ecode");
						if(s1.equalsIgnoreCase("true"))
						{
					     Toast.makeText(CreditActivity1.this,"added suceful",Toast.LENGTH_LONG ).show();
					     restartFirstActivity();
					 }
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Log.i("Tag", "*******"+res);
		 }

			  
	}
private void restartFirstActivity()
{
    finish();
	overridePendingTransition( 0, 0);
	startActivity(getIntent());
	overridePendingTransition( 0, 0);
}
	}

		 
		
		 
	
