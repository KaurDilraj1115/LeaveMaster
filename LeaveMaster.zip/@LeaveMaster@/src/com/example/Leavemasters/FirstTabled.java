package com.example.Leavemasters;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.Leavemasters.FirstTab.Statuscreditlist;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class FirstTabled extends Activity{
	ProgressDialog pdialog;
	  String res,cll2,pll2,compl2,othersl2,datel2,e1,d1,d2;
	  
	TextView t11,t21,t31,t41,t51;
	 TableLayout FIRST1_table;
	 TableRow rows;
	 protected void onCreate(Bundle savedInstanceState) 
		{
			super.onCreate(savedInstanceState);
			setContentView(R.layout.firstled);
			firsts_table();
			new Ledgercreditlist().execute();
			SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE); 
			e1=   pref.getString("ecode", null);         
		    d2=    pref.getString("fdate", null);
		    d2=    pref.getString("ddate", null);
		  
		    String e1=   pref.getString("ecode", null);          
		    String d1=    pref.getString("fdate", null); 
		    String d2=    pref.getString("ddate", null);
			 
			  
		}

	private void firsts_table() {
		// TODO Auto-generated method stub
		
	}

	public  class Ledgercreditlist extends AsyncTask<Void, Void, Void>
	 {
		@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				pdialog = new ProgressDialog(FirstTabled.this);
				pdialog.setMessage("Please wait...");
				pdialog.setCancelable(false);
				pdialog.show();
		        super.onPreExecute();
			  }
		@Override
		protected Void doInBackground(Void... params) {
			// TODO Auto-generated method stub
			// TODO Auto-generated method stub
			JSONObject jobj = new JSONObject();
 			ServiceHandler sh = new ServiceHandler();
 			String url = "http://javat.drishinfo.com/LeaveProject-war/MyService";
 		try 
 			{
 			    List<NameValuePair> nameValuePairsList = new ArrayList<NameValuePair>();
				nameValuePairsList.add(new BasicNameValuePair("operation","ledger"));
				nameValuePairsList.add(new BasicNameValuePair("empcode",e1));
			    nameValuePairsList.add(new BasicNameValuePair("date1",d2));
			    nameValuePairsList.add(new BasicNameValuePair("date2",d1));
		        res = sh.makeServiceCall(url, ServiceHandler.GET,nameValuePairsList);
		        Log.i( "TAG","tag"+res+d1+d2);
				 
			} 
 			catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} 
 	return null;
		 
	 }
		@Override
		protected void onPostExecute(Void result) 
	{
		// TODO Auto-generated method stub
		if (pdialog.isShowing())
			pdialog.dismiss();
		super.onPostExecute(result);
		 try {
		 Log.i("TAG", res);
			
			 JSONObject jobj7 =  new  JSONObject((res));
			JSONArray jarray=jobj7.getJSONArray("Creditstatus");
			for(int i=0;i<jarray.length();i++)
			{
				Log.i("TAG", "lelist");
				JSONObject jobj4=jarray.getJSONObject(i);
				cll2=jobj4.getString("cl");
				 pll2=jobj4.getString("pl");
				 compl2=jobj4.getString("comp");
				othersl2=jobj4.getString("others");
				datel2=jobj4.getString("cdate");
			firsts_table(  cll2,pll2,compl2,othersl2,datel2) ;
			
				}
			}
	 catch (JSONException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
private void firsts_table(String cll2,String pll2,String compl2,String othersl2,String datel2) 
{
			// TODO Auto-generated method stub
	  FIRST1_table=(TableLayout)findViewById(R.id.FIRST11_table);
	

int dip = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, (float) 1, getResources().getDisplayMetrics());
	            rows = new TableRow(FirstTabled.this);
	            t11= new TextView(FirstTabled.this);
	            t21 =new TextView(FirstTabled.this);
	            t31=new TextView(FirstTabled.this);
	           t41=new TextView(FirstTabled.this);
	          
	           t11.setText(datel2);
	           t21.setText(cll2);
	            t31.setText(pll2);
	            t41.setText(compl2);
	            t51.setText(othersl2);
	           

	          
	            t11.setTypeface(null, 1);
	            t21.setTypeface(null, 1);
	            t31.setTypeface(null, 1);
	            t41.setTypeface(null, 1);
	            t51.setTypeface(null, 1);
         
	          
	            t11.setTextSize(15);
	            t21.setTextSize(15);
	            t31.setTextSize(15);
	            t41.setTextSize(15);
	            t51.setTextSize(15);
	            
	            t11.setGravity(Gravity.CENTER);
	            t21.setGravity(Gravity.CENTER);
	            t31.setGravity(Gravity.CENTER);
	            t41.setGravity(Gravity.CENTER);
	            t51.setGravity(Gravity.CENTER);
	           

	            t11.setWidth(80*dip);
	            t11.setHeight(30*dip);
	            t21.setWidth(60*dip);
	            t21.setHeight(30*dip);
	            t31.setWidth(60*dip);
	            t31.setHeight(30* dip);
	            t41.setWidth(60*dip);
	            t41.setHeight(30*dip);

	            t51.setWidth(80*dip);
	            t51.setHeight(30*dip);
//	           
//	               t11.setPadding(40*dip, 0, 0, 0);
//		           t21.setPadding(90*dip, 0, 0, 0); 
//		           t31.setPadding(80*dip, 0, 0, 0);
//		           t41.setPadding(20*dip, 0, 0, 0);
//		           t51.setPadding(20*dip, 0, 0, 0);
		            
	            rows.addView(t11);
	            rows.addView(t21);
	            rows.addView(t31);
	            rows.addView(t41);
	            rows.addView(t51);
	           
	           FIRST1_table.addView(rows);

	
}
}


}
