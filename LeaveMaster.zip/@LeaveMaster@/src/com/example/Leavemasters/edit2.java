package com.example.Leavemasters;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class edit2 extends Activity implements OnClickListener{

	EditText email_id;
	EditText fname;
	EditText ename;
	String res;
	EditText empname;
	EditText empcode;
	EditText fathrname;
	EditText emailid;
	EditText usertype;
	EditText managerid;
	EditText address;
	EditText doj;
	EditText doc;
	EditText mobile;
	Button b1;
	String code1,fname1,emname,eid;
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.edit2);
	
	    empcode=(EditText)findViewById(R.id.editText1);
	  empname=(EditText)findViewById(R.id.editText2);
	 fathrname=(EditText)findViewById(R.id.editText5);
	  emailid=(EditText)findViewById(R.id.editText4);
	  usertype=(EditText)findViewById(R.id.editText3);
      managerid=(EditText)findViewById(R.id.editText6);
      address=(EditText)findViewById(R.id.editText10);
      doj=(EditText)findViewById(R.id.editText8);
      doc=(EditText)findViewById(R.id.editText9);
      mobile=(EditText)findViewById(R.id.editText7);

      // getting intent data
       Intent in = getIntent();
       
       // Get JSON values from previous intent
       this.code1 = in.getStringExtra("code");
       this.fname1=in.getStringExtra("fathername");
       this.emname=in.getStringExtra("empname");
       this.eid=in.getStringExtra("email");

       
       // Displaying all values on the screen
   
      // TextView Emp_code = (TextView) findViewById(R.id.text12_edit1);
      
       empcode.setText(code1);
       fathrname.setText(fname1);
       empname.setText(emname);
       emailid.setText(eid);

       
		
      b1=(Button)findViewById(R.id.button1);

   b1.setOnClickListener(this);
	
	 
	}
	 class editempy extends AsyncTask<Void,Void,Void>{
		  @Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
			super.onPreExecute();
		}

		@Override
		protected Void doInBackground(Void... params) {
			// TODO Auto-generated method stub
			String url="http://javat.drishinfo.com/LeaveProject-war/MyService";
			ServiceHandler sh = new ServiceHandler();		
			JSONObject jobj = new JSONObject();
			Log.i("tag", url);
			
			try {
				jobj.put("empcode",empcode.getText().toString());
				jobj.put("empname",empname.getText().toString());
				jobj.put("fname", fathrname.getText().toString());
				jobj.put("email",emailid.getText().toString() );
				jobj.put("usertype",usertype.getText().toString());
				jobj.put("managerid", managerid.getText().toString());
				jobj.put("address",address.getText().toString());
				jobj.put("doj",doj.getText().toString());
				jobj.put("doc",doc.getText().toString());
				jobj.put("mobile", mobile.getText().toString());
				List<NameValuePair> nameValuePairsList = new ArrayList<NameValuePair>();			
				nameValuePairsList.add(new BasicNameValuePair("operation","edit"));
				nameValuePairsList.add(new BasicNameValuePair("editStr", jobj.toString()));
				res = sh.makeServiceCall(url, ServiceHandler.GET,nameValuePairsList);
				
				Log.i("TAG", "***"+managerid.getText().toString());
				Log.i("Tag", res);
				
				
			
			
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
			 return null;
          		}
		@Override
		protected void onPostExecute(final Void result) 
		{
			// TODO Auto-generated method stub
	try {
		JSONObject job=new JSONObject(res);
		final String s= job.getString("result");
		
		Log.i("Tag", "*******"+s);

	  			if(s.equals("true"))
	  			{
	  				Toast.makeText(edit2.this, "edited succesful",Toast.LENGTH_LONG).show();
	  				 restartFirstActivity();
	  				
	  			}

		
	} catch (JSONException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
			super.onPostExecute(result);
		}
	 }
	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		new editempy().execute();
	}

	private void restartFirstActivity()
	{
	    finish();
		overridePendingTransition( 0, 0);
		startActivity(getIntent());
		overridePendingTransition( 0, 0);
	}		
}
