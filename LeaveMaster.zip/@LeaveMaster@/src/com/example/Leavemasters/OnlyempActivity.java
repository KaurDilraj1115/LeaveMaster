package com.example.Leavemasters;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;

public class OnlyempActivity extends Activity {
ImageButton rep;
Button lout,cpwd;
String q1,q2;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_onlyemp);
		SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
	     final Editor editor = pref.edit();
		q1=   pref.getString("username", null);         
	    q2=    pref.getString("usertype", null);
	    rep=(ImageButton)findViewById(R.id.REPRTLIST);
		lout=(Button)findViewById(R.id.Button1);
		lout.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				editor.clear();
			    editor.commit();
				Intent l=new Intent(OnlyempActivity.this, Login_page.class);
				// Closing all the Activities
			    l.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			    // Add new Flag to start new Activity
			    l.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK );
			    // Staring Login Activity
				startActivity(l);
				
			}
		});
		cpwd=(Button)findViewById(R.id.Button3);
		cpwd.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent ic=new Intent(OnlyempActivity.this,Changepwd.class);
				startActivity(ic);
				
			}
		});
		rep.setOnClickListener(new  View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent re=new Intent(OnlyempActivity.this,EmpreportActivity.class);
				startActivity(re);
			}
		} );
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.onlyemp, menu);
		return true;
	}

}
