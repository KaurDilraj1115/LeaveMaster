package com.example.Leavemasters;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;



import android.app.Activity;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class ThirdTab extends Activity{
	 ProgressDialog pdialog;
	  String res,tscl,tspl,tscomp,tsothers,p1,p2;
	  
	TextView t1,t2,t3;
	 TableLayout third_table;
	 TableRow rows;
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.third);
		third_table();
		new Statusopenlist().execute();
		SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE); 
		p1=   pref.getString("ecode", null);         
	    p2=    pref.getString("edate", null);
	    Log.i("TAG","emp" +p1+p2);
	
	}			
//}
	 private void third_table() {
		// TODO Auto-generated method stub
		
	}
	public  class Statusopenlist extends AsyncTask<Void, Void, Void>
	 {

		 
		 @Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				pdialog = new ProgressDialog(ThirdTab.this);
				pdialog.setMessage("Please wait...");
				pdialog.setCancelable(false);
				pdialog.show();
		        super.onPreExecute();
			  }
		@Override
		protected Void doInBackground(Void... params) {
			// TODO Auto-generated method stub
			// TODO Auto-generated method stub
			JSONObject jobj = new JSONObject();
 			ServiceHandler sh = new ServiceHandler();
 			String url = "http://javat.drishinfo.com/LeaveProject-war/MyService";
 		
 			try 
 			{
 			
				List<NameValuePair> nameValuePairsList = new ArrayList<NameValuePair>();
				nameValuePairsList.add(new BasicNameValuePair("operation","status1"));
				nameValuePairsList.add(new BasicNameValuePair("empcode",p1));
			    nameValuePairsList.add(new BasicNameValuePair("ldate",p2.replaceAll("\\s","")));
		        res = sh.makeServiceCall(url, ServiceHandler.GET,nameValuePairsList);
				  Log.i("TAG", res);
			} 
 			catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} 
 	return null;
		 
	 }
		@Override
		protected void onPostExecute(Void result) 
	{
		// TODO Auto-generated method stub
		if (pdialog.isShowing())
			pdialog.dismiss();
		super.onPostExecute(result);
		 try {
		//	 Log.i("TAG", res);
			
			 JSONObject jobj7 =  new  JSONObject((res));
			JSONArray jarray=jobj7.getJSONArray("Openingstatus");
			for(int i=0;i<jarray.length();i++)
			{
				Log.i("TAG", "dlist");
				JSONObject jobj4=jarray.getJSONObject(i);
				tscl=jobj4.getString("cl");
				 tspl=jobj4.getString("pl");
				 tscomp=jobj4.getString("comp");
				// tsothers=jobj4.getString("");
				 
			
			third_table( tscl,tspl,tscomp//tsothers
					) ;
			
				}
			}
	 catch (JSONException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
private void third_table(String tscl,String tspl,String tscomp // String tsothers
		) 
{
			// TODO Auto-generated method stub
	  third_table=(TableLayout)findViewById(R.id.third_table);
	// TODO Auto-generated method stub

int dip = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, (float) 1, getResources().getDisplayMetrics());
	            rows = new TableRow(ThirdTab.this);
	            t1 = new TextView(ThirdTab.this);
	            t2 =new TextView(ThirdTab.this);
	            t3=new TextView(ThirdTab.this);
	          //  t4=new TextView(FirstTab.this);
	          

	            t1.setText(tscl);
	            t2.setText(tspl);
	            t3.setText(tscomp);
	          //  t4.setText(tsothers);
	          

	          
	            t1.setTypeface(null, 1);
	            t2.setTypeface(null, 1);
	            t3.setTypeface(null, 1);
	           // t4.setTypeface(null, 1);
//	            t5.setTypeface(null, 1);
//	            t6.setTypeface(null, 1);
//	            t7.setTypeface(null, 1);
//	            t8.setTypeface(null, 1);
//	            t9.setTypeface(null, 1);
//	            
	          
	            t1.setTextSize(15);
	            t2.setTextSize(15);
	            t3.setTextSize(15);
	         //   t4.setTextSize(15);
	            
	            
	            t1.setGravity(Gravity.CENTER);
	            t2.setGravity(Gravity.CENTER);
	            t3.setGravity(Gravity.CENTER);
	            //t4.setGravity(Gravity.CENTER);
	           

	            t1.setWidth(110*dip);
	            t1.setHeight(30*dip);
	            t2.setWidth(140*dip);
	            t2.setHeight(30*dip);
	            t3.setWidth(170*dip);
	            t3.setHeight(30* dip);
//	            t4.setWidth(170*dip);
//	            t4.setHeight(30*dip);
//	            t4.setWidth(80*dip);
//	            t4.setHeight(40*dip);
	            t1.setPadding(50*dip, 0, 0, 0);
		           t2.setPadding(100*dip, 0, 0, 0); 
		           t3.setPadding(100*dip, 0, 0, 0);
		          // t4.setPadding(20*dip, 0, 0, 0);
		            
	          
	            rows.addView(t1);
	            rows.addView(t2);
	            rows.addView(t3);
	         //   rows.addView(t4);
	           
	           third_table.addView(rows);

	
}
}

}
