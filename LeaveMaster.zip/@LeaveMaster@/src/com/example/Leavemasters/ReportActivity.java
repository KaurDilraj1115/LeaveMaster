package com.example.Leavemasters;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;

public class ReportActivity extends Activity {

	Button led;
	Button st;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_report);
		
		led=(Button)findViewById(R.id.ledr);
		st=(Button)findViewById(R.id.sts);
		
led.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent led1=new Intent(ReportActivity.this, Mainledger.class);
				startActivity(led1);
				finish();
				
			}
		});

st.setOnClickListener(new View.OnClickListener() {
	
	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		Intent sts1=new Intent(ReportActivity.this,  Mainstatus.class);
		startActivity(sts1);
		finish();
		
	}
});
		

	}

	

}
