
package com.example.Leavemasters;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;

import android.widget.Button;
import android.widget.ImageButton;

public class EmpButtonActivity extends Activity 
{
	ImageButton b11,b12,b13,b16;
	Button chngpwd,lout;
	String q1,q2;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_emp_button);
		
		b11=(ImageButton)findViewById(R.id.EMPLIST);
		b12=(ImageButton)findViewById(R.id.CREDITLIST);
		b13=(ImageButton)findViewById(R.id.DEBITLIST);
	    b16=(ImageButton)findViewById(R.id.REPRTLIST);
		 SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
		       final Editor editor = pref.edit();
			q1=   pref.getString("username", null);         
		    q2=    pref.getString("usertype", null);
		chngpwd=(Button)findViewById(R.id.imageButton3);
		chngpwd.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent cp =new Intent(EmpButtonActivity.this,Changepwd.class);
				startActivity(cp);
				finish();
				}
		});
		lout=(Button)findViewById(R.id.logout);
		lout.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				editor.clear();
			    editor.commit();
				Intent l=new Intent(EmpButtonActivity.this, Login_page.class);
				// Closing all the Activities
			    l.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			    // Add new Flag to start new Activity
			    l.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK );
			    // Staring Login Activity
				startActivity(l);
				
			}
		});
		
			b11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent ynm=new Intent(EmpButtonActivity.this, employerecord.class);
				startActivity(ynm);
				finish();
				
			}
		});

		b13.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent db=new Intent(EmpButtonActivity.this, DebitActivity.class);
				startActivity(db);
				finish();
				
			}
		});

		b16.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent ret=new Intent(EmpButtonActivity.this, ReportActivity.class);
				startActivity(ret);
				finish();
		}
		});
		
	b12.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent cred=new Intent(EmpButtonActivity.this,CreditActivity1.class);
				startActivity(cred);
				finish();
		
		
	}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.emp_button, menu);
		return true;
	}

}
