package com.example.Leavemasters;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class Mainstatusemp extends Activity {
	 Button btyem;
	 EditText et2;
	 Spinner spem;
	 ImageButton imem,ib;
	 String res,q1,q2,s211;
	 private Calendar cal;
	 private int day;
	 private int month;
	 private int year;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_mainstatusemp);
		ib = (ImageButton) findViewById(R.id.imageButton115);
	    cal = Calendar.getInstance();
	    day = cal.get(Calendar.DAY_OF_MONTH);
	    month = cal.get(Calendar.MONTH);
	    year = cal.get(Calendar.YEAR);
	    et2 = (EditText) findViewById(R.id.editTextt5);
		   ib.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					showDialog(0);
					}});
		btyem=(Button)findViewById(R.id.stst5);
	
	
		SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE); 
			q1=   pref.getString("username", null);         
		    q2=    pref.getString("usertype", null);
		   new emplist12().execute();
		btyem.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent btyy=new Intent(Mainstatusemp.this,ShowstatusActivity.class);
				startActivity(btyy);
			}});
	}
	 @Override
	 protected Dialog onCreateDialog(int id) {
	  return new DatePickerDialog(this, datePickerListener, year, month, day);
	 }
      private DatePickerDialog.OnDateSetListener datePickerListener = new DatePickerDialog.OnDateSetListener() {
	  public void onDateSet(DatePicker view, int selectedYear,int selectedMonth, int selectedDay) 
	  {
	   et2.setText((selectedMonth + 1)+ " / " +  +selectedDay + " / " + selectedYear);

	}
	};
	 public class emplist12 extends AsyncTask<Void, Void, Void>
	 {
		 List<String> emolist2=new ArrayList<String>();
			 @Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
               super.onPreExecute();
			  }
         @Override
		protected Void doInBackground(Void... arg0) {
			// TODO Auto-generated method stub
        	  Log.i("TAG","usetype" +q1+q2);
			JSONObject j11 = new JSONObject();
  			ServiceHandler sh = new ServiceHandler();
  		    String url = "http://javat.drishinfo.com/LeaveProject-war/MyService";
  			Log.i("TAG", "elist"+url);
  			List<NameValuePair> nameValuePairsList = new ArrayList<NameValuePair>();
			nameValuePairsList.add(new BasicNameValuePair("operation","Emplist"));
			nameValuePairsList.add(new BasicNameValuePair("empcode",q1));
			nameValuePairsList.add(new BasicNameValuePair("usertype",q2));
			 res = sh.makeServiceCall(url, ServiceHandler.GET,nameValuePairsList);
			  Log.i("TAG", res);
			return null;
		}
		@Override
		protected void onPostExecute(Void result) 
	{
		// TODO Auto-generated method stub
        Log.i("TAG","usetype2" +q1+q2);
		super.onPostExecute(result);
		 try {
			JSONObject j33 =  new  JSONObject(res);
			JSONArray jarray=j33.getJSONArray("emplist");
			for(int i=0;i<jarray.length();i++)
			{
			
             emolist2.add(jarray.getString(i));   
			}
			spem=(Spinner)findViewById(R.id.spinner25);
			
ArrayAdapter<String> adapter = new ArrayAdapter<String>(Mainstatusemp.this,android.R.layout.simple_spinner_item, emolist2);
adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
  spem.setAdapter(adapter);
  spem.setOnItemSelectedListener(new OnItemSelectedListener() {

	@Override
	public void onItemSelected(AdapterView<?> arg0, View arg1, int position,long arg3) {
		// TODO Auto-generated method stub
	    String str=spem.getSelectedItem().toString();
		s211=et2.getText().toString();
		 SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE); 
		   Editor editor = pref.edit();
		  editor.putString("ecode",str);  
	      editor.putString("edate",s211 );
	      editor.commit();
	      String d1=   pref.getString("ecode", null);          
	      String d2=    pref.getString("edate", null); 
		if(str.length()>0&&s211.length()>0)
		 {
			 Log.i("TAG", "position"+position);
          }
		 else
		 {
		Toast.makeText(Mainstatusemp.this, "plz fill date and empcode",Toast.LENGTH_LONG).show(); 
	      }
	}
  @Override
	public void onNothingSelected(AdapterView<?> arg0) {// TODO Auto-generated method stub
	  Toast.makeText(Mainstatusemp.this, "plz fill date and empcode",Toast.LENGTH_LONG).show();
	}
});
				}
	 catch (JSONException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	} 
		 }
	
	
}
