package com.example.Leavemasters;

import java.util.List;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import android.widget.TextView;

public class CustomAdapter<MyViewHolder> extends BaseAdapter{
	
	Activity activity;
	LayoutInflater inflater;
	List<UserData> userDataList1;
	
	public CustomAdapter(Activity activity, List<UserData> userDatas) {
		this.activity = activity;
		this.userDataList1 = userDatas;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return userDataList1.size();
	}

	@Override
	public Object getItem(int arg0) {
		// TODO Auto-generated method stub
		return userDataList1.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return arg0;
	}

	@Override
	public View getView(int arg0, View convertView, ViewGroup arg2)
	{
		// TODO Auto-generated method stub
			
		
		
		if(convertView==null)
		{
			LayoutInflater inflater=(LayoutInflater) activity.getSystemService(activity.LAYOUT_INFLATER_SERVICE);
			convertView=inflater.inflate(R.layout.dil3,null);
		}
		
		@SuppressWarnings("unused")
	
		TextView employ_id=(TextView) convertView.findViewById(R.id.empcode1);
		TextView employ_name =(TextView) convertView.findViewById(R.id.empname1);
		TextView manager_id=(TextView) convertView.findViewById(R.id.managerid1);
	
		
		UserData user=userDataList1.get(arg0);
		employ_id.setText(user.getEmpcode());
		 employ_name.setText(user.getEmpname());
		  manager_id.setText(user.getManagerid());
		
		
		return convertView;
		}
		}
	
