package com.example.Leavemasters;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.Leavemasters.SecondTabled.Ledgerdebitlist;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class Sled extends Activity {
	 ProgressDialog pdialog;
	  String res,cll,pll,compl,othersl,datel,p1,p2,e1,d1,d2;
	  
	TextView t1,t2,t3,t4,t5;
	 TableLayout Second2_table;
	 TableRow rows;
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sled);
		second_table();
		new Ledgerdebitlist().execute();
		SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE); 
		e1=   pref.getString("ecode", null);         
	    d1=    pref.getString("fdate", null);
	    d2=    pref.getString("ddate", null);
	  
	    String e1=   pref.getString("ecode", null);          
	    String d1=    pref.getString("fdate", null); 
	    String d2=    pref.getString("ddate", null);
	}	
	

	 private void second_table() {
		// TODO Auto-generated method stub
		
	}
	public  class Ledgerdebitlist extends AsyncTask<Void, Void, Void>
	 {

		 
		 @Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				pdialog = new ProgressDialog(Sled.this);
				pdialog.setMessage("Please wait...");
				pdialog.setCancelable(false);
				pdialog.show();
		        super.onPreExecute();
			  }
		@Override
		protected Void doInBackground(Void... params) {
			// TODO Auto-generated method stub
			// TODO Auto-generated method stub
			JSONObject jobj = new JSONObject();
			ServiceHandler sh = new ServiceHandler();
			String url = "http://javat.drishinfo.com/LeaveProject-war/MyService";
		
			try 
			{
			
				List<NameValuePair> nameValuePairsList = new ArrayList<NameValuePair>();
				nameValuePairsList.add(new BasicNameValuePair("operation","ledger"));
				nameValuePairsList.add(new BasicNameValuePair("empcode",e1));
			    nameValuePairsList.add(new BasicNameValuePair("date1",d2));
			    nameValuePairsList.add(new BasicNameValuePair("date2",d1));
		        res = sh.makeServiceCall(url, ServiceHandler.GET,nameValuePairsList);
		        Log.i( "TAG","tag"+res+d1+d2);
			} 
			catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} 
	return null;
		 
	 }
		@Override
		protected void onPostExecute(Void result) 
	{
		// TODO Auto-generated method stub
		if (pdialog.isShowing())
			pdialog.dismiss();
		super.onPostExecute(result);
		 try {
		//	 Log.i("TAG", res);
			
			 JSONObject jobj5 =  new  JSONObject((res));
			JSONArray jarray=jobj5.getJSONArray("Debitstatus");
			for(int i=0;i<jarray.length();i++)
			{
				Log.i("TAG", "dlist");
				JSONObject jobj6=jarray.getJSONObject(i);
				 cll=jobj6.getString("cl");
				 pll=jobj6.getString("pl");
				 compl=jobj6.getString("comp");
				othersl=jobj6.getString("others");
				datel=jobj6.getString("ddate");
			
			second2_table( cll,pll,compl,othersl,datel) ;
			
				}
			}
	 catch (JSONException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
private void second2_table(String cll,String pll,String compl,String othersl,String datel
		) 
{
			// TODO Auto-generated method stub
	  Second2_table=(TableLayout)findViewById(R.id.SECOND2_table);
	// TODO Auto-generated method stub

int dip = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, (float) 1, getResources().getDisplayMetrics());
	            rows = new TableRow(Sled.this);
	            t1 = new TextView(Sled.this);
	            t2 =new TextView(Sled.this);
	            t3=new TextView(Sled.this);
	            t4=new TextView(Sled.this);
	            t5=new TextView(Sled.this);
	           
	            t1.setText(datel);
	            t2.setText(cll);
	            t3.setText(pll);
	            t4.setText(compl);
	            t5.setText(othersl);
	           

	          
	            t1.setTypeface(null, 1);
	            t2.setTypeface(null, 1);
	            t3.setTypeface(null, 1);
	            t4.setTypeface(null, 1);
	            t5.setTypeface(null, 1);
         
	          
	            t1.setTextSize(15);
	            t2.setTextSize(15);
	            t3.setTextSize(15);
	           t4.setTextSize(15);
	              t5.setTextSize(15);
	            
	            t1.setGravity(Gravity.CENTER);
	            t2.setGravity(Gravity.CENTER);
	            t3.setGravity(Gravity.CENTER);
	            t4.setGravity(Gravity.CENTER);
	            t5.setGravity(Gravity.CENTER);
	           

	            t1.setWidth(80*dip);
	            t1.setHeight(30*dip);
	            t2.setWidth(60*dip);
	            t2.setHeight(30*dip);
	            t3.setWidth(60*dip);
	            t3.setHeight(30* dip);
	            t4.setWidth(60*dip);
	            t4.setHeight(30*dip);
	            t5.setWidth(80*dip);
	            t5.setHeight(30*dip);
		            
	            rows.addView(t1);
	            rows.addView(t2);
	            rows.addView(t3);
	            rows.addView(t4);
	            rows.addView(t5);
	           Second2_table.addView(rows);

	
}
}



}



