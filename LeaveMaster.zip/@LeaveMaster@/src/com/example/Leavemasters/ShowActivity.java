package com.example.Leavemasters;

//import android.R;
import android.os.Bundle;
import android.app.Activity;
import android.app.TabActivity;

import android.content.Intent;

import android.view.Menu;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;


            public class ShowActivity extends TabActivity {
            	@Override
            	public void onCreate(Bundle savedInstanceState) {
            	super.onCreate(savedInstanceState);
            	setContentView(R.layout.activity_show);

            	
          TabHost tabHost = (TabHost)findViewById(android.R.id.tabhost);

            	

            	
          TabSpec firstTabSpec = tabHost.newTabSpec("tid1");
          TabSpec secondTabSpec = tabHost.newTabSpec("tid1");
          TabSpec thirdTabSpec = tabHost.newTabSpec("tid1");
          TabSpec fourthTabSpec = tabHost.newTabSpec("tid1");
            	
          firstTabSpec.setIndicator("Credit Leave").setContent(new Intent(this,FirstTab.class));
      	secondTabSpec.setIndicator("Debit Leave").setContent(new Intent(this,SecondTab.class));
      	 thirdTabSpec.setIndicator("Opening Bal").setContent(new Intent(this,ThirdTab.class));
       	fourthTabSpec.setIndicator("Closing Bal").setContent(new Intent(this,FourthTab.class));
       
            	tabHost.addTab(firstTabSpec);
            	tabHost.addTab(secondTabSpec);
            	tabHost.addTab(thirdTabSpec);
            	tabHost.addTab(fourthTabSpec);
            	}
            	}