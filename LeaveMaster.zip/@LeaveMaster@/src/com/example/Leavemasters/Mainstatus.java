package com.example.Leavemasters;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.Leavemasters.CreditActivity1.EmplistTask;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class Mainstatus extends Activity implements OnClickListener {
	
	Button bty;
	EditText et1;
	Spinner sp;
	ImageButton im,ib;
	String q1,q2,res,s21;
	 private Calendar cal;
	 private int day;
	 private int month;
	 private int year;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_mainstatus);
		ib = (ImageButton) findViewById(R.id.imageButton13);
	    cal = Calendar.getInstance();
	    day = cal.get(Calendar.DAY_OF_MONTH);
	    month = cal.get(Calendar.MONTH);
	    year = cal.get(Calendar.YEAR);
		bty=(Button)findViewById(R.id.stst);
	
		 et1 = (EditText) findViewById(R.id.editTextt);
		   ib.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					showDialog(0);
					}});
		
		 SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE); 
			q1=   pref.getString("username", null);         
		    q2=    pref.getString("usertype", null);
		    Log.i("TAG","emp" +q1+q2);
		bty.setOnClickListener(new View.OnClickListener() 
		{
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent btyy=new Intent(Mainstatus.this,ShowActivity.class);
				startActivity(btyy);
			}
		}
		);
		new emplist1().execute();
	}
	
	
	 @Override
	 protected Dialog onCreateDialog(int id) {
	  return new DatePickerDialog(this, datePickerListener, year, month, day);
	 }
      private DatePickerDialog.OnDateSetListener datePickerListener = new DatePickerDialog.OnDateSetListener() {
	  public void onDateSet(DatePicker view, int selectedYear,int selectedMonth, int selectedDay) 
	  {
	   et1.setText((selectedMonth + 1)+ " / " +  +selectedDay + " / " + selectedYear);

	}
	};
	 public class emplist1 extends AsyncTask<Void, Void, Void>
	 {
		 
			List<String> emolist=new ArrayList<String>();
			
			
		  @Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub

		      super.onPreExecute();
			  }
          @Override
		protected Void doInBackground(Void... arg0) {
			// TODO Auto-generated method stub
        	  Log.i("TAG","usetype" +q1+q2);
			JSONObject j11 = new JSONObject();
  			ServiceHandler sh = new ServiceHandler();
  		
  			String url = "http://javat.drishinfo.com/LeaveProject-war/MyService";
  			Log.i("TAG", "elist"+url);
  			List<NameValuePair> nameValuePairsList = new ArrayList<NameValuePair>();
			nameValuePairsList.add(new BasicNameValuePair("operation","Emplist"));
			nameValuePairsList.add(new BasicNameValuePair("empcode",q1));
			nameValuePairsList.add(new BasicNameValuePair("usertype",q2));
			 res = sh.makeServiceCall(url, ServiceHandler.GET,nameValuePairsList);
			  Log.i("TAG", res);
			return null;
		}
		@Override
		protected void onPostExecute(Void result) 
	{
		// TODO Auto-generated method stub

			 Log.i("TAG","usetype2" +q1+q2);
		super.onPostExecute(result);
		 try {
			JSONObject j33 =  new  JSONObject(res);
			JSONArray jarray=j33.getJSONArray("emplist");
			
			for(int i=0;i<jarray.length();i++)
			{
				Log.i("TAG", "list");

				
		     emolist.add(jarray.getString(i));   
			}
				 sp =(Spinner)findViewById(R.id.spinner2);
			
ArrayAdapter<String> adapter = new ArrayAdapter<String>(Mainstatus.this,android.R.layout.simple_spinner_item, emolist);
adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
  sp.setAdapter(adapter);
  sp.setOnItemSelectedListener(new OnItemSelectedListener() {

	@Override
	public void onItemSelected(AdapterView<?> arg0, View arg1, int position,
			long arg3) {
		// TODO Auto-generated method stub
	    String  str=sp.getSelectedItem().toString();
		 s21=et1.getText().toString();
		 SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE); 
		   Editor editor = pref.edit();
		  editor.putString("ecode",str);  
	      editor.putString("edate",s21 );
	      editor.commit();
	      String p1=   pref.getString("ecode", null);          
	      String p2=    pref.getString("edate", null); 
		
		 if(str.length()>0&&s21.length()>0)
		 {
			 Log.i("TAG", "position"+position);
		
		 }
		 else
		 {
			  Toast.makeText(Mainstatus.this, "plz fill date and empcode",Toast.LENGTH_LONG).show(); 
		 }
	
			}
  @Override
	public void onNothingSelected(AdapterView<?> arg0) {// TODO Auto-generated method stub
	  Toast.makeText(Mainstatus.this, "plz fill date and empcode",Toast.LENGTH_LONG).show();
	}
});
				}
	 catch (JSONException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	} 
		 }
	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		
	}

	
}
