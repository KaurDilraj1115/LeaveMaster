package com.example.Leavemasters;


import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;


import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Changepwd extends Activity {
	 EditText e1;
	 EditText e2;
	String res,res1,q1,q2;
    private ProgressDialog pDialog;
	EditText e3,e4;
	Button chngpas,chngpas1;
	 String s1,s3,s4;
	 String s2;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		
		setContentView(R.layout.changepwd);
		e2=(EditText)findViewById(R.id.oldpas);
		 e3=(EditText)findViewById(R.id.chngpas);
		 e4=(EditText)findViewById(R.id.cfrmpas);
//		 e4=(EditText)findViewById(R.id.empco);
		chngpas=(Button)findViewById(R.id.save);
//		SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE); 
//	    
//	    
//	   q1= pref.getString("username", null);
//	     q2=pref.getString("usertype", null);
chngpas.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
//				s1=e1.getText().toString();
//				s2=e2.getText().toString();
//				s3=e3.getText().toString();
//				s4=e4.getText().toString();
				new chngpassword().execute();
			}
		});
		
		
	}


	class chngpassword extends AsyncTask<Void, Void, Void> {

		@Override
		protected void onPreExecute() {
			pDialog = new ProgressDialog(Changepwd.this);
			pDialog.setMessage("Please wait...");
			pDialog.setCancelable(false);
			pDialog.show();

			// TODO Auto-generated method stub
			super.onPreExecute();
		}

		@Override
		protected Void doInBackground(Void... params) {
			// TODO Auto-generated method stub
			// URL =
			// "http://javat.drishinfo.com/MyDeal-war/loginServlet?
			// operation=login&loginStr={\"username\":\"admin\",\"password\":\"admin\"}"
			ServiceHandler sh = new ServiceHandler();
			String url = "http://javat.drishinfo.com/LeaveProject-war/MyService";
			JSONObject jObj = new JSONObject();
			try {
				 
//				login.setOnClickListener(new OnClickListener() {
//					
//					@Override
//					public void onClick(View arg0) {
//						// TODO Auto-generated method stub
//						s1=e1.getText().toString();
//						s2=e2.getText().toString();
//						new LoginTask().execute();
//					}
//				});
				jObj.put("empcode", "E001");
				jObj.put("oldpass", e2.getText().toString());
				jObj.put("newpass", e3.getText().toString());
				jObj.put("confirmpass", e4.getText().toString());

				List<NameValuePair> nameValuePairsList = new ArrayList<NameValuePair>();
				nameValuePairsList.add(new BasicNameValuePair("operation",
						"changepassword"));
				nameValuePairsList.add(new BasicNameValuePair("changeStr", jObj
						.toString()));
Log.i("TAG", "&&&&"+jObj);
				 res = sh.makeServiceCall(url, ServiceHandler.GET,
						nameValuePairsList);
				Log.i("TAG","response -------- " + res);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if (pDialog.isShowing())
				pDialog.dismiss();
			
			try {
				JSONObject obj=new JSONObject(res);
				String s=obj.getString("result");
				
				if(s.equalsIgnoreCase("true"))
				{
					Toast.makeText(Changepwd.this,"Password Changed",Toast.LENGTH_LONG ).show();
				
					Intent cp=new Intent(Changepwd.this,Login_page.class);
					startActivity(cp);
				}
			
			
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	}
	}




