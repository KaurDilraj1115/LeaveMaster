package com.example.Leavemasters;

//import android.R;
import android.os.Bundle;
import android.app.Activity;
import android.app.TabActivity;

import android.content.Intent;

import android.view.Menu;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;


            public class ShowstatusActivity extends TabActivity {
            	@Override
            	public void onCreate(Bundle savedInstanceState) {
            	super.onCreate(savedInstanceState);
            	setContentView(R.layout.activity_showemp);

            	
          TabHost tabHost = (TabHost)findViewById(android.R.id.tabhost);

            	

            	
          TabSpec firstTabSpec = tabHost.newTabSpec("tid1");
          TabSpec secondTabSpec = tabHost.newTabSpec("tid1");
          TabSpec thirdTabSpec = tabHost.newTabSpec("tid1");
          TabSpec fourthTabSpec = tabHost.newTabSpec("tid1");
            	
          firstTabSpec.setIndicator("Credit Leave").setContent(new Intent(this,FirstTabemp.class));
      	secondTabSpec.setIndicator("Debit Leave").setContent(new Intent(this,SecondTabemp.class));
      	 thirdTabSpec.setIndicator("Opening Bal").setContent(new Intent(this,ThirdTabemp.class));
       	fourthTabSpec.setIndicator("Closing Bal").setContent(new Intent(this,FourthTabemp.class));
       
            	tabHost.addTab(firstTabSpec);
            	tabHost.addTab(secondTabSpec);
            	tabHost.addTab(thirdTabSpec);
            	tabHost.addTab(fourthTabSpec);
            	}
            	}