package com.example.Leavemasters;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class Login_page extends Activity implements OnClickListener {
	
    EditText e1,e2;
    String s1,s2;
    Button ln;
    String res,q1,q2;
    TextView forgetpwd;
	ProgressDialog pdialog;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
	    setContentView(R.layout.login);
         e1=(EditText)findViewById(R.id.user);
		 e2=(EditText)findViewById(R.id.pass);
		
		 forgetpwd=(TextView)findViewById(R.id.oki);
        forgetpwd.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				new Forpwd().execute();
			}
		});
		 ln=(Button)findViewById(R.id.button1);
		 ln.setOnClickListener(this);
		}

class LoginTask extends AsyncTask<Void, Void, Void> {
	
         @Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			pdialog = new ProgressDialog(Login_page.this);
			pdialog.setMessage("please wait...");
			pdialog.setCancelable(false);
			pdialog.setIndeterminate(true);
			pdialog.show();
		    super.onPreExecute();
			
			}

		@Override
		protected Void doInBackground(Void... params) {
			// TODO Auto-generated method stub
			
			ServiceHandler sh = new ServiceHandler();
			String url = "http://javat.drishinfo.com/LeaveProject-war/MyService";
			JSONObject jObj = new JSONObject();
			try {
				jObj.put("username", s1);
				jObj.put("password",s2);
				List<NameValuePair> nameValuePairsList = new ArrayList<NameValuePair>();
				nameValuePairsList.add(new BasicNameValuePair("operation","login"));
				nameValuePairsList.add(new BasicNameValuePair("loginStr", jObj.toString()));
                  Log.i("TAG", "&&&&"+jObj);
				  res = sh.makeServiceCall(url, ServiceHandler.GET,nameValuePairsList);
				  Log.i("TAG","response -------- " + res);
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}
       @Override
		protected void onPostExecute(Void result) 
		{
			// TODO Auto-generated method stub
			if (pdialog.isShowing())
				pdialog.dismiss();
			 super.onPostExecute(result);
			try
			{
				JSONObject jobj=new JSONObject((res));
		      	String response1=	jobj.get("validation").toString();
		      	String response2= jobj.get("usertype").toString();
	   if(e1.getText().length()>0 && e2.getText().length()>0)
	      	{
	    	  if(response1.equals("true")&& response2.equals("admin") )
	    	  	{
		    		Intent in=new Intent(Login_page.this,EmpButtonActivity.class);
					startActivity(in);
		      	}
				else if(response1.equals("true")&& response2.equalsIgnoreCase(("manager")))
		      	{
					Intent in=new Intent(Login_page.this,OnlyempActivity.class);
					startActivity(in);
		         }
				else if(response1.equals("true")&& response2.equalsIgnoreCase(("Employee")))
		      	{
					Intent in=new Intent(Login_page.this,OnlyempActivity.class);
					startActivity(in);
		         }
				else if(response1.equals("false")&& response2.equals("admin") )
	    	  	{
	    		  Toast.makeText(Login_page.this, "Your Password is incorrect",Toast.LENGTH_LONG ).show();
		      	}
				else if(response1.equals("false")&& response2.equalsIgnoreCase(("manager")))
		      	{
					 Toast.makeText(Login_page.this, "Your Password is incorrect",Toast.LENGTH_LONG ).show();
		         }
				else if(response1.equals("false")&& response2.equalsIgnoreCase(("Employee")))
		      	{
					 Toast.makeText(Login_page.this, "Your Password is incorrect",Toast.LENGTH_LONG ).show();
		         }
				 }
		       else
			      	{
			      Toast.makeText(Login_page.this, "please fill id & pw",Toast.LENGTH_LONG ).show();	
			      	}
	 
		SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE); 
		   Editor editor = pref.edit();
		  editor.putString("username",s1);  
	      editor.putString("usertype",response2 );
	      editor.commit();
	    String q1=   pref.getString("username", null);          
	    String q2=    pref.getString("usertype", null); 
		      	
		     }
		      	
	    
			 catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
public void onClick(View arg0) {
		// TODO Auto-generated method stub
	 s1=e1.getText().toString();
	s2=e2.getText().toString();
		new LoginTask().execute();
	}
	 class Forpwd extends AsyncTask<Void, Void, Void>
	 {
	 
   @Override
	protected void onPreExecute() {
		// TODO Auto-generated method stub
		pdialog = new ProgressDialog(Login_page.this);
		pdialog.setMessage("Please wait...");
		pdialog.setCancelable(false);
		pdialog.show();
      super.onPreExecute();
	  }

	@Override
  		protected Void doInBackground(Void... params) {
  			// TODO Auto-generated method stub
  			JSONObject jobj = new JSONObject();
  			ServiceHandler sh = new ServiceHandler();
  			
  			String url = "http://javat.drishinfo.com/LeaveProject-war/MyService";
  			try {
  				jobj.put("username", s1);
  			    List<NameValuePair> nameValuePairsList = new ArrayList<NameValuePair>();
				nameValuePairsList.add(new BasicNameValuePair("operation","fpassword"));
				nameValuePairsList.add(new BasicNameValuePair("empcode",s1));
		      res = sh.makeServiceCall(url, ServiceHandler.GET,nameValuePairsList);
				  Log.i("TAG", res);
			} 
  			catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();} 
  	return null;
  		}
	
	@Override
		protected void onPostExecute(Void result) 
	{
		// TODO Auto-generated method stub
		if (pdialog.isShowing())
			pdialog.dismiss();
		super.onPostExecute(result);
		try {
			JSONObject jobj=new JSONObject(res);
			String s1= jobj.getString("result");
			if(s1.length()>0)
			{
			if(s1.equals("true"))
			{
		Toast.makeText(Login_page.this,"Your Password is mailed to your email",Toast.LENGTH_LONG ).show();
			}
			}
			else
			{
		Toast.makeText(Login_page.this,"plz fill empcode first",Toast.LENGTH_LONG ).show();	
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

}
}
