package com.example.Leavemasters;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.Leavemasters.CreditActivity1.EmplistTask;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.TableLayout.LayoutParams;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class DebitActivity extends Activity implements OnClickListener {
	Spinner spinnerDropDown2;
	 private Calendar cal;
	 private int day;
	 private int month;
	 private int year;
	 private EditText et;
	 ProgressDialog pdialog;
	 String debittypes, otherss, debitdates ,mls,cls,pls,lwps,ecodes,absents,comps;
	 EditText e1, e2, e3 ,e4,e5,e6,e7,e8,e9;
     ImageButton ib,ed,adddebitrows;
	  String s1,s2,s3,s4,s5,s6,s7,s8,s9,q1,q2,str2,s112,res;
	  TableRow row;
	 // String empcode11;
	  TableLayout record_table;
	  TextView t1,t2,t3,t4,t5,t6,t7,t8,t9;
		@Override
	   protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.debit);
          ib = (ImageButton) findViewById(R.id.imageButton1);
		  cal = Calendar.getInstance();
		  day = cal.get(Calendar.DAY_OF_MONTH);
		  month = cal.get(Calendar.MONTH);
		  year = cal.get(Calendar.YEAR);
		  et = (EditText) findViewById(R.id.editText);
		  ib.setOnClickListener(this);
		  ed=(ImageButton)findViewById(R.id.edit);
		  record_table=(TableLayout)findViewById(R.id.record_table);
	      adddebitrows=(ImageButton)findViewById(R.id.addrow);
	      
	      SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE); 
		   q1=   pref.getString("username", null);         
		   q2=    pref.getString("usertype", null);
		   new emplist2().execute();
		    Log.i("TAG","emp" +q1+q2);
            e1=(EditText)findViewById(R.id.tv_12);
		    e2=(EditText)findViewById(R.id.tv_13);
		    e3=(EditText)findViewById(R.id.tv_14);
			e4=(EditText)findViewById(R.id.tv_15);
			e5=(EditText)findViewById(R.id.tv_16);
			e6=(EditText)findViewById(R.id.tv_mll);
			e7=(EditText)findViewById(R.id.tv_17);
			e8=(EditText)findViewById(R.id.tv_18);
			e9=(EditText)findViewById(R.id.tv_20);
			record_table();
	       List<String> dlist=new ArrayList<String>();
            Log.i("tag", "heloo");	
        adddebitrows.setOnClickListener(new OnClickListener() {
	    @Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		new Debitadd().execute();
		}});
      ed.setOnClickListener(new View.OnClickListener() {
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		s1=e1.getText().toString();
		s2=e2.getText().toString();
		s3=e3.getText().toString();
		s4=e4.getText().toString();
		s5=e5.getText().toString();
		s6=e6.getText().toString();
		s7=e7.getText().toString();
		s8=e8.getText().toString();
		s9=e9.getText().toString();
		new Debitedit().execute();
		}
});
      }
	        
private void record_table() {
		// TODO Auto-generated method stub
	}
public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
		 {
		 // Get select item
		 int sid=spinnerDropDown2.getSelectedItemPosition();
          }
		 public void onNothingSelected(AdapterView<?> parent)
		 {
		 // TODO Auto-generated method stub 
		  }
        @Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			  showDialog(0);
		}
		 @Override
			
		 protected Dialog onCreateDialog(int id) {
		  return new DatePickerDialog(this, datePickerListener, year, month, day);
		 }

		 private DatePickerDialog.OnDateSetListener datePickerListener = new DatePickerDialog.OnDateSetListener() {
		  public void onDateSet(DatePicker view, int selectedYear,int selectedMonth, int selectedDay) 
		  {
			 et.setText((selectedMonth + 1)+ " / " +  +selectedDay + " / " + selectedYear);
		  }
		 };

		 public class emplist2 extends AsyncTask<Void, Void, Void>
		 {
			 List<String> emlist2=new ArrayList<String>();
				 @Override
				protected void onPreExecute() {
					// TODO Auto-generated method stub
                  super.onPreExecute();
				  }
              @Override
			protected Void doInBackground(Void... arg0) {
				// TODO Auto-generated method stub
            	  Log.i("TAG","usetype" +q1+q2);
				JSONObject j1 = new JSONObject();
	  			ServiceHandler sh = new ServiceHandler();
	  			String url = "http://javat.drishinfo.com/LeaveProject-war/MyService";
	  			List<NameValuePair> nameValuePairsList = new ArrayList<NameValuePair>();
				nameValuePairsList.add(new BasicNameValuePair("operation","Emplist"));
				nameValuePairsList.add(new BasicNameValuePair("empcode",q1));
				nameValuePairsList.add(new BasicNameValuePair("usertype",q2));
				 res = sh.makeServiceCall(url, ServiceHandler.GET,nameValuePairsList);
				  Log.i("TAG", res);
				return null;
			}
			@Override
			protected void onPostExecute(Void result) 
		{
			// TODO Auto-generated method stub

				 Log.i("TAG","usetype2" +q1+q2);
			super.onPostExecute(result);
			 try {
				JSONObject j3 =  new  JSONObject(res);
				JSONArray jarray=j3.getJSONArray("emplist");
				
				for(int i=0;i<jarray.length();i++)
				{
					Log.i("TAG", "list");

					
			     emlist2.add(jarray.getString(i));   
				}
					 spinnerDropDown2 =(Spinner)findViewById(R.id.spinner1);
				
ArrayAdapter<String> adapter = new ArrayAdapter<String>(DebitActivity.this,android.R.layout.simple_spinner_item, emlist2);
	adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
	  spinnerDropDown2.setAdapter(adapter);
	  spinnerDropDown2.setOnItemSelectedListener(new OnItemSelectedListener() {

		@Override
		public void onItemSelected(AdapterView<?> arg0, View arg1, int position,
				long arg3) {
			// TODO Auto-generated method stub
		      str2=spinnerDropDown2.getSelectedItem().toString();
			  s112=et.getText().toString();
			
			 if(str2.length()>0&&s112.length()>0)
			 {
				 Log.i("TAG", "position"+position);
			 new DebitlistTask().execute(str2);
			 }
			 else
			 {
				 Toast.makeText(DebitActivity.this, "plz fill date and empcode",Toast.LENGTH_LONG).show();
			 }		
			}

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			// TODO Auto-generated method stub
			}
	});
	}
	catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		} }
		  public  class DebitlistTask extends AsyncTask<String,String,String>
		 {
			 @Override
				protected void onPreExecute() {
					// TODO Auto-generated method stub 
					pdialog = new ProgressDialog(DebitActivity.this);
					pdialog.setMessage("Please wait...");
					pdialog.setCancelable(false);
					pdialog.show();
			        super.onPreExecute();
				  }

                     @Override
			  		protected String doInBackground(String... params) {
			  			// TODO Auto-generated method stub 
                    	 //s112.replaceAll("\\s","") 
			  			JSONObject jobj = new JSONObject();
			  			
			  			Log.i("TAG", "***"+params[0]);
			  			String empcode11=params[0];
			  			ServiceHandler sh = new ServiceHandler();
			  			String url = "http://javat.drishinfo.com/LeaveProject-war/MyService";
			  			try {
			  				
							List<NameValuePair> nameValuePairsList = new ArrayList<NameValuePair>();
							nameValuePairsList.add(new BasicNameValuePair("operation","drlist"));
							Log.i("TAG", "@@@@@@"+params[0]+"****"+s112);
							nameValuePairsList.add(new BasicNameValuePair("empcode",params[0]));
						   nameValuePairsList.add(new BasicNameValuePair("drdate","01/17/2015"));
					      res = sh.makeServiceCall(url, ServiceHandler.GET,nameValuePairsList);
							  Log.i("TAG", res);
						} 
			  			catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} 
			  	return null;
			  		}
				
  @Override
			protected void onPostExecute(String result) 
		{
			// TODO Auto-generated method stub
			if (pdialog.isShowing())
				pdialog.dismiss();
			super.onPostExecute(result);
			 try {
			    JSONObject jobj7 =  new  JSONObject((res));
				JSONArray jarray=jobj7.getJSONArray("debitlist");
				record_table.removeAllViews();
				for(int i=0;i<jarray.length();i++)
				{
					Log.i("TAG", "dlist");
					JSONObject jobj9=jarray.getJSONObject(i);
					 lwps=jobj9.getString("lwp");
					 cls=jobj9.getString("cl");
					 pls=jobj9.getString("pl");
					 debittypes=jobj9.getString("debittype");
					 ecodes=jobj9.getString("ecode");
					 otherss=jobj9.getString("others");
					 debitdates=jobj9.getString("debitdate");
					 mls=jobj9.getString("ml");
					comps=jobj9.getString("comp");
				record_table( ecodes,debitdates, debittypes, cls, pls,comps ,lwps,absents ,otherss ) ;
				}
				}
		 catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	private void record_table(String ecode,String debitdate,String debitytpe,String cl,String pl,String comp,String lwp,String absent , String others ) 
	{
		   // TODO Auto-generated method stub
		  //record_table=(TableLayout)findViewById(R.id.record_table);
int dip = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, (float) 1, getResources().getDisplayMetrics());
		            row = new TableRow(DebitActivity.this);
		            t1 = new TextView(DebitActivity.this);
		            t2 = new TextView(DebitActivity.this);
		            t3=new TextView(DebitActivity.this);
		            t4=new TextView(DebitActivity.this);
		            t5=new TextView(DebitActivity.this);
		            t6=new TextView(DebitActivity.this);
		            t7=new TextView(DebitActivity.this);
		            t8=new TextView(DebitActivity.this);
		            t9=new TextView(DebitActivity.this);
		            
                    t1.setText(ecodes);
		            t2.setText(debitdates);
		            t3.setText(debittypes);
		            t4.setText(cls);
		            t5.setText(pls);
		            t6.setText(mls);
		            t7.setText(comps);
		            t8.setText(lwps);
		            t9.setText(otherss);
		            
                    t1.setTextSize(15);
		            t2.setTextSize(15);
		            t3.setTextSize(15);
		            t4.setTextSize(15);
		            t5.setTextSize(15);
		            t6.setTextSize(15);
		            t7.setTextSize(15);
		            t8.setTextSize(15);
		            t9.setTextSize(15);
		            
		            t1.setGravity(Gravity.CENTER);
		            t2.setGravity(Gravity.CENTER);
		            t3.setGravity(Gravity.CENTER);
		            t1.setGravity(Gravity.CENTER);
		            t1.setGravity(Gravity.CENTER);
		            t1.setGravity(Gravity.CENTER);
		            t1.setGravity(Gravity.CENTER);
		            t1.setGravity(Gravity.CENTER);
		            t1.setGravity(Gravity.CENTER);

		            t1.setWidth(65*dip);
		            t1.setHeight(40*dip);
		            t2.setWidth(80*dip);
		            t2.setHeight(40*dip);
		            t3.setWidth(80*dip);
		            t3.setHeight(40* dip);
		            t4.setWidth(60*dip);
		            t4.setHeight(40*dip);
		            t5.setWidth(60*dip);
		            t5.setHeight(40*dip);
		            t6.setWidth(60*dip);
		            t6.setHeight(40*dip);
		            t7.setWidth(60*dip);
		            t7.setHeight(40*dip);
		            t8.setWidth(65*dip);
		            t8.setHeight(40*dip);
		            t9.setWidth(60*dip);
		            t9.setHeight(40*dip);
		            row.setLayoutParams(new LayoutParams( 
		            LayoutParams.MATCH_PARENT,LayoutParams.WRAP_CONTENT));
		          
		            row.addView(t1);
		            row.addView(t2);
		            row.addView(t3);
		            row.addView(t4);
		            row.addView(t5);
		            row.addView(t6);
		            row.addView(t7);
		            row.addView(t8);
		            row.addView(t9);
		           record_table.addView(row);

		           row.setOnClickListener(new OnClickListener() {
		  			 @Override
		  			 public void onClick(View v) {
		  			 // TODO Auto-generated method stub
		  			 TableRow t = (TableRow) v;
		  			      TextView firstTextView = (TextView) t.getChildAt(0);
		  			      TextView secondTextView = (TextView) t.getChildAt(1);
		  			      TextView thirdTextView = (TextView) t.getChildAt(2);
		  			      TextView fourthTextView = (TextView) t.getChildAt(3);
		  			      TextView fifthTextView = (TextView) t.getChildAt(4);
		  			      TextView sixthTextView = (TextView) t.getChildAt(5);
		  			      TextView seventhTextView = (TextView) t.getChildAt(6);
		  			      TextView eigthTextView = (TextView) t.getChildAt(7);
		  			      TextView ninthTextView = (TextView) t.getChildAt(8);
		  			      
		  			      String firstText = firstTextView.getText().toString();
		  			      String secondText = secondTextView.getText().toString();
		  			      String thirdText = thirdTextView.getText().toString();
		  			      String fourthText = fourthTextView.getText().toString();
		  			      String fifthText = fifthTextView.getText().toString();
		  			      String sixthText = sixthTextView.getText().toString();
		  			      String seventhText = fourthTextView.getText().toString();
		  			      String eigthText = fifthTextView.getText().toString();
		  			      String ninthText = sixthTextView.getText().toString();
		  			      
		  			      Log.i("TAG", "******"+firstText+"%%%%%%"+secondText);

		  			      e1.setText(firstText);
		  			      e2.setText(secondText);
		  			      e3.setText(thirdText);
		  			      e4.setText(fourthText);
		  			      e5.setText(fifthText);
		  			      e6.setText(sixthText);
		  			      e7.setText(seventhText);
		  			      e8.setText(eigthText);
		  			      e9.setText(ninthText);
		  			       }
		  			 });
}

	private void row(int matchParent, int wrapContent) {
		// TODO Auto-generated method stub
		}

	
		 }
	
	public class Debitedit extends AsyncTask<Void,Void,Void>
	{
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			pdialog = new ProgressDialog(DebitActivity.this);
			pdialog.setMessage("Please wait...");
			pdialog.setCancelable(false);
			pdialog.show();
           super.onPreExecute();
		}

		@Override
		protected Void doInBackground(Void...params) {
			// TODO Auto-generated method stub
			String url = "http://javat.drishinfo.com/LeaveProject-war/MyService";
			ServiceHandler sh = new ServiceHandler();
		    JSONObject jobj1 = new JSONObject();
		try {
			jobj1.put("ecode", s1);
			jobj1.put("debitdate", s2);
			jobj1.put("debittype", s3);
			jobj1.put("cl", s4);
			jobj1.put("pl", s5);
			jobj1.put("ml", s6);
			jobj1.put("comp",s7);
			jobj1.put("lwp", s8);
			jobj1.put("others",s9);
			Log.i("TAG", "***"+jobj1.toString());
		  List<NameValuePair> nameValuePairsList = new ArrayList<NameValuePair>();			
		nameValuePairsList.add(new BasicNameValuePair("operation","dedit"));
		nameValuePairsList.add(new BasicNameValuePair("deditStr", jobj1.toString()));
	    res = sh.makeServiceCall(url, ServiceHandler.GET,nameValuePairsList);
	   Log.i("TAG", "res"+res);
						} 
		catch (JSONException e) {
	// TODO Auto-generated catch block
		e.printStackTrace();
				}
		return null;
		}
		@Override
		protected void onPostExecute(Void result) 
		{
			// TODO Auto-generated method stub
			if (pdialog.isShowing())
				pdialog.dismiss();
			
			try {
				Log.i("TAG","res"+res);
				JSONObject jobj2;
				jobj2 = new JSONObject(res);
				String s1= jobj2.getString("result");
				Log.i("TAG","drishhhhhhhhh"+s1);
         if(s1.equals("true"))
				{
			Toast.makeText(DebitActivity.this,"edited suceful",Toast.LENGTH_LONG ).show();
			restartFirstActivity();
						}
         else
         {
        	 Toast.makeText(DebitActivity.this,"not edited",Toast.LENGTH_LONG ).show();
 			restartFirstActivity(); 
         }
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        super.onPostExecute(result);
		}
	}
		public class Debitadd extends AsyncTask<Void,Void,Void>
		 {
			@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
				pdialog = new ProgressDialog(DebitActivity.this);
				pdialog.setMessage("Please wait...");
				pdialog.setCancelable(false);
				pdialog.show();
	           super.onPreExecute();
			}
           @Override
			protected Void doInBackground(Void... arg0) {
				// TODO Auto-generated method stub
				String url= "http://javat.drishinfo.com/LeaveProject-war/MyService";
				ServiceHandler sh = new ServiceHandler();	
				JSONObject obj=new JSONObject();
			try {
					obj.put("ecode", e1.getText().toString());
					obj.put("debitdate", e2.getText().toString());
					obj.put("dtype", e3.getText().toString());
					obj.put("cl",  e4.getText().toString());
					obj.put("pl", e5.getText().toString());
					obj.put("ml",e6.getText().toString());
					obj.put("comp",  e7.getText().toString());
					obj.put("lwp", e8.getText().toString());
					obj.put("others",e9.getText().toString());
					
					
					List<NameValuePair> nameValuePairsList = new ArrayList<NameValuePair>();			
					nameValuePairsList.add(new BasicNameValuePair("operation","registerdebit"));
					nameValuePairsList.add(new BasicNameValuePair("registerdebitStr", obj.toString()));
					res = sh.makeServiceCall(url, ServiceHandler.GET,nameValuePairsList);
					Log.i("tag","resadd"+res);
					
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				return null;
			}
			@Override
			protected void onPostExecute(Void result) 
			{
				// TODO Auto-generated method stub
				if (pdialog.isShowing())
					pdialog.dismiss();
		try {
						JSONObject jobj=new JSONObject(res);
						String s1= jobj.getString("result");
			            Log.i("Tag", "*******"+"ecode");
						if(s1.equalsIgnoreCase("true"))
						{
					     Toast.makeText(DebitActivity.this,"added suceful",Toast.LENGTH_LONG ).show();
					     restartFirstActivity(); 
					 }
					} catch (JSONException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Log.i("Tag", "*******"+res);
		 }
	}
 private void restartFirstActivity()
			 {
	             finish();
				overridePendingTransition( 0, 0);
				startActivity(getIntent());
				overridePendingTransition( 0, 0);
			 }
	   }	

