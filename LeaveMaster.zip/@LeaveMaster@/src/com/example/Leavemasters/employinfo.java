package com.example.Leavemasters;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract.CommonDataKinds.Email;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
public class employinfo extends Activity {
	TextView email, fathername, empname,utype,mid,pno,doj,doc,addr;
    Button edit,delete,back;
    private String code ;
	 String res;
	protected void onCreate(Bundle savedInstanceState) {
	       super.onCreate(savedInstanceState);
	       setContentView(R.layout.edit1);
	     email = (TextView)findViewById(R.id.text15_edit1);
	     fathername=(TextView)findViewById(R.id.text17_edit1);
	     empname=(TextView)findViewById(R.id.text13_edit1);
	     utype=(TextView)findViewById(R.id.text14_edit1);
	     mid=(TextView)findViewById(R.id.text16_edit1);
	     pno=(TextView)findViewById(R.id.textView18);
	     doj=(TextView)findViewById(R.id.text19_edit1);
	     doc=(TextView)findViewById(R.id.textView1);
	     addr=(TextView)findViewById(R.id.textView2);
	     back=(Button)findViewById(R.id. button2_edit1);
	     back.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent it=new Intent(employinfo.this,employerecord.class);
				startActivity(it);
				
			}
		});
	     delete=(Button)findViewById(R.id.button1_delete);
	     delete.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				new deleteemp().execute();
			}
		});
	      
               Intent in = getIntent();
	        this.code = in.getStringExtra("empcode");
	        TextView Emp_code = (TextView) findViewById(R.id.text12_edit1);
            Emp_code.setText(code);
	      new employeinformation().execute();
 }
class employeinformation extends AsyncTask<Void,Void,Void>
{
	private String empcode;
    @Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
		super.onPreExecute();
	}

 @Override
	protected Void doInBackground(Void... params) {
		// TODO Auto-generated method stub
		String url="http://javat.drishinfo.com/LeaveProject-war/MyService";
		Log.i("TAg",url );
		ServiceHandler sh = new ServiceHandler();		
		JSONObject jobj = new JSONObject();
		List<NameValuePair> nameValuePairsList = new ArrayList<NameValuePair>();
		nameValuePairsList.add(new BasicNameValuePair("operation","sclick"));
		Log.i("TAG",code);
  nameValuePairsList.add(new BasicNameValuePair("empcode",code));
   res = sh.makeServiceCall(url, ServiceHandler.GET,
			nameValuePairsList);
			
		return null;
	}
	@Override
	protected void onPostExecute(Void result) {
		// TODO Auto-generated method stub
		try {
			JSONObject jobj = new JSONObject(res);
			 final String eid = jobj.getString("email");
			 final String ename= jobj.getString("empname");
			 final String fname=jobj.getString("fathername");
			 final String add=jobj.getString("address");
			 final String ustype=jobj.getString("usertype");
			 final String mob=jobj.getString("mobile");
			 //final String dj=jobj.getString("doj");
			// final String dc=jobj.getString("doc");
			 final String mnid=jobj.getString("managerid");
			 Log.i("TAG", "fff"+fname+ename+mob);
			email.setText(eid);
			fathername.setText(fname);
		    empname.setText(ename);
		    utype.setText(ustype);
		    pno.setText(mob);
		    mid.setText(mnid);
		    //doj.setText(dj);
		  //  doc.setText(dc);
		    
		    edit=(Button)findViewById(R.id.button1_edit1);
		    edit.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					Intent in=new Intent(employinfo.this,edit2.class);
					in.putExtra( "code",code);
					in.putExtra("fathername", fname);
					in.putExtra("email",eid );
					in.putExtra("empname", ename);
					startActivity(in);
					}
			});
		
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		super.onPostExecute(result);
	}

}
class deleteemp extends AsyncTask<Void,Void,Void>
{
	private String empcode;
    @Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
		super.onPreExecute();
	}

 @Override
	protected Void doInBackground(Void... params) {
		// TODO Auto-generated method stub
	    String url="http://javat.drishinfo.com/LeaveProject-war/MyService";
		ServiceHandler sh = new ServiceHandler();		
		JSONObject jobj = new JSONObject();
		List<NameValuePair> nameValuePairsList = new ArrayList<NameValuePair>();
		nameValuePairsList.add(new BasicNameValuePair("operation","delete"));
	
      nameValuePairsList.add(new BasicNameValuePair("empcode",code));
   res = sh.makeServiceCall(url, ServiceHandler.GET,nameValuePairsList);
			return null;
	}
	@Override
	protected void onPostExecute(Void result) {
		// TODO Auto-generated method stub
		try {
			JSONObject jobj=new JSONObject(res);
			String s1= jobj.getString("result");
            if(s1.equals("true"))
			{
		     Toast.makeText(employinfo.this,"deleted succeful",Toast.LENGTH_LONG ).show();
		     restartFirstActivity();
		 }
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		super.onPostExecute(result);
	}}
private void restartFirstActivity()
{
	
    finish();
	overridePendingTransition( 0, 0);
	startActivity(getIntent());
	overridePendingTransition( 0, 0);
}
	}
