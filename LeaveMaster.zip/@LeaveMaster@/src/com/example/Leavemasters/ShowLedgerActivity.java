package com.example.Leavemasters;

import android.os.Bundle;
import android.app.Activity;
import android.app.TabActivity;
import android.content.Intent;
import android.view.Menu;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class ShowLedgerActivity extends TabActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.showledger);
    	TabHost tabHost1 = (TabHost)findViewById(android.R.id.tabhost);
        TabSpec firstTabSpec1 = tabHost1.newTabSpec("tid11");
        TabSpec secondTabSpec1 = tabHost1.newTabSpec("tid11");
        TabSpec thirdTabSpec1 = tabHost1.newTabSpec("tid11");
      //  TabSpec fourthTabSpec = tabHost.newTabSpec("tid1");
          	
        firstTabSpec1.setIndicator("Credit Leave").setContent(new Intent(this,FirstTabled.class));
    	secondTabSpec1.setIndicator("Debit Leave").setContent(new Intent(this,SecondTabled.class));
    	 thirdTabSpec1.setIndicator("Opening Bal").setContent(new Intent(this,ThirdTabled.class));
     //	fourthTabSpec.setIndicator("Closing Bal").setContent(new Intent(this,FourthTab.class));
     
          	tabHost1.addTab(firstTabSpec1);
          	tabHost1.addTab(secondTabSpec1);
          	tabHost1.addTab(thirdTabSpec1);
        //  	tabHost.addTab(fourthTabSpec);
          	}
          	
	

	
}
