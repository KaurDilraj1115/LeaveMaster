package com.example.Leavemasters;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;

public class SplashScreenprojActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splash_screenproj);
		 Thread t=new Thread(new Runnable()
			
			{

				@Override
				public void run() 
				{
					// TODO Auto-generated method stub
					try
					{
						Thread.sleep(1000);
						
					}
					catch(Exception e)
					{
						e.printStackTrace();
					}
					
					Intent i4=new Intent(SplashScreenprojActivity.this,Login_page.class);
			        startActivity(i4);
			      	finish();
			     }
				
		     }
			
				
			);
			  
		t.start();	
		
		}

		
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.splash_screenproj, menu);
		return true;
	}

}
