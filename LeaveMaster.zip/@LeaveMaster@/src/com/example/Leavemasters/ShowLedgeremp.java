package com.example.Leavemasters;

import android.os.Bundle;
import android.app.Activity;
import android.app.TabActivity;
import android.content.Intent;
import android.view.Menu;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class ShowLedgeremp extends TabActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.showledgeremp);
		 TabHost tabHost = (TabHost)findViewById(android.R.id.tabhost);

       	

       	
	        TabSpec firstTabSpec = tabHost.newTabSpec("tid1");
	        TabSpec secondTabSpec = tabHost.newTabSpec("tid1");
	        TabSpec thirdTabSpec = tabHost.newTabSpec("tid1");
	      //  TabSpec fourthTabSpec = tabHost.newTabSpec("tid1");
	          	
	        firstTabSpec.setIndicator("Credit Leave").setContent(new Intent(this,Fled.class));
	    	secondTabSpec.setIndicator("Debit Leave").setContent(new Intent(this,Sled.class));
	    	 thirdTabSpec.setIndicator("Opening Bal").setContent(new Intent(this,Tled.class));
	     //	fourthTabSpec.setIndicator("Closing Bal").setContent(new Intent(this,FourthTab.class));
	     
	          	tabHost.addTab(firstTabSpec);
	          	tabHost.addTab(secondTabSpec);
	          	tabHost.addTab(thirdTabSpec);
	        //  	tabHost.addTab(fourthTabSpec);
	}

	

}
