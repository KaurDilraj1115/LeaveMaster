package com.example.Leavemasters;


	
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.location.GpsStatus.Listener;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
	public class employerecord extends Activity {
		ListView list;
	   CustomAdapter custom;
	   EmployeData employee;
	   Button bt;
	   ArrayList<UserData> userDataList1;
		String managerid, empcode, empname, res, emprec,EmpRec;
	    JSONArray emprecord;;
			@Override
	   protected void onCreate(Bundle savedInstanceState) {
	       super.onCreate(savedInstanceState);
	       setContentView(R.layout.activity_record);
	   List<String> empList=new ArrayList<String>();
	       userDataList1=new ArrayList<UserData>();
	 ArrayList<HashMap<String, String>> employList;
		employList = new ArrayList<HashMap<String, String>>();
		bt=(Button)findViewById(R.id.button1_record);
		bt.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i=new Intent(employerecord.this,addemployee.class);
				startActivity(i);
				
			}
		});

		new EmplistTask().execute();
		 }
			
	public  class EmplistTask extends AsyncTask<Void, Void, Void> {
			 @Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
			super.onPreExecute();
		}

			@Override
			protected Void doInBackground(Void... params) {
				// TODO Auto-generated method stub
				String url = "http://javat.drishinfo.com/LeaveProject-war/MyLeaveService";
			
				ServiceHandler sh = new ServiceHandler();
				JSONObject jobject=new JSONObject();
		
		try {
				jobject.put("button"," EmpRec");
				List<NameValuePair> nameValuePairsList = new ArrayList<NameValuePair>();
				nameValuePairsList.add(new BasicNameValuePair("button",
						"EmpRec"));
				String res = sh.makeServiceCall(url, ServiceHandler.GET,
							nameValuePairsList);
				 Log.i("TAG", res);
					JSONObject jobj =  new  JSONObject(res);
					JSONArray jarray=jobj.getJSONArray("emplist");
				
				 
					for(int i=0;i<jarray.length();i++)
					{
									UserData user = new UserData();
						Log.i("TAG", "list");
						JSONObject jobj2=jarray.getJSONObject(i);
					    String empname=jobj2.getString("empname");
						String empcode=jobj2.getString("empcode");
						String managerid=jobj2.getString("managerid");
						Log.i("TAG", "&&&&"+empname+empcode+managerid);
						//HashMap<String, String> emprecord = new HashMap<String, String>();
				
						user.setEmpcode(empcode);
						user.setEmpname(empname);
						user.setManagerid(managerid);
					    userDataList1.add(user);
						
					}
					
			}
		catch (JSONException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		return null;
			}

			@Override
			protected void onPostExecute(Void result) {
				// TODO Auto-generated method stub
				super.onPostExecute(result);
			 try {

				    ListView list = (ListView)findViewById(R.id.listView1);
		
				   CustomAdapter<UserData> adapter=new CustomAdapter<UserData>
		        (employerecord.this,userDataList1);
		        list.setAdapter(adapter);
		     

				

		    list.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> parent, View view,
						int position, long id) {
					// TODO Auto-generated method stub
					 
					String empcode=((TextView)view.findViewById(R.id.empcode1)).getText().toString();
					Intent in=new Intent(employerecord.this,employinfo.class);
					in.putExtra( "empcode",empcode);
					startActivity(in);
					 // Toast.makeText(employerecord.this,"clicked succeful",Toast.LENGTH_LONG ).show();
					
				}
			});
		

		
			 }
			 catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					}
			}
	}
	}


			



			



	    





