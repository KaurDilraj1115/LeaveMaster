package com.example.Leavemasters;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class addemployee extends Activity implements OnClickListener  {
	String res;

	EditText ecode,pwd,ename,sques,ans,utype,mid,address,doj,doc,email,fname,mobile,rtyp;
	Button b,b1;
	  protected void onCreate(Bundle savedInstanceState) {
	       super.onCreate(savedInstanceState);
	       setContentView(R.layout.add2t);
	   
	      ecode=(EditText)findViewById(R.id.editText1);
	      rtyp=(EditText)findViewById(R.id.editText9);
	      pwd= (EditText)findViewById(R.id.editText8);
	      ename=(EditText)findViewById(R.id.editText2);
	      
	     
	      utype=(EditText)findViewById(R.id.editText3);
	      mid=(EditText)findViewById(R.id.editText5);
	      address=(EditText)findViewById(R.id.editText14);
	      doj=(EditText)findViewById(R.id.editText12);
	      doc=(EditText)findViewById(R.id.editText13);
	      email=(EditText)findViewById(R.id.editText4);
	      fname=(EditText)findViewById(R.id.editText6);
	      mobile=(EditText)findViewById(R.id.editText7);
	      
	  
	       b=(Button)findViewById(R.id.button2);
	       b1=(Button)findViewById(R.id.button1);
	       b1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				  ecode.setText("");
				  pwd.setText("");
			      ename.setText("");
			     
			      utype.setText("");
			      mid.setText("");
			      address.setText("");
			      doj.setText("");
			      doc.setText("");
			      email.setText("");
			      fname.setText("");
			      mobile.setText("");
			      rtyp.setText("");
				
			}
		});
	     b.setOnClickListener(this);
	   
 }
	  class empadd extends AsyncTask<Void,Void,Void>{
		
		@Override
			protected void onPreExecute() {
				// TODO Auto-generated method stub
			
			super.onPreExecute();
		}


		@Override
		protected Void doInBackground(Void... arg0) {
			// TODO Auto-generated method stub
		
			String url= "http://javat.drishinfo.com/LeaveProject-war/MyService";
			ServiceHandler sh = new ServiceHandler();	
			JSONObject obj=new JSONObject();
			
			
			try {
				obj.put("empcode", ecode.getText().toString());
				obj.put("password", pwd.getText().toString());
				obj.put("empname", ename.getText().toString());
//				obj.put("secq", sques.getText().toString());
//				obj.put("answer", ans.getText().toString());
				obj.put("usertype",utype.getText().toString());
				obj.put("managerid", mid.getText().toString());
				obj.put("address",address.getText().toString());
				obj.put("doj", doj.getText().toString());
				obj.put("doc", doc.getText().toString());
				obj.put("email", email.getText().toString());
				obj.put("fname", fname.getText().toString());
				obj.put("mobile", mobile.getText().toString());
				List<NameValuePair> nameValuePairsList = new ArrayList<NameValuePair>();			
				nameValuePairsList.add(new BasicNameValuePair("operation","register"));
				nameValuePairsList.add(new BasicNameValuePair("registerStr", obj.toString()));
				res = sh.makeServiceCall(url, ServiceHandler.GET,nameValuePairsList);
				Log.i("tag","res"+res);
				
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return null;
		}
		
		@Override
		protected void onPostExecute(Void result) 
		{
			// TODO Auto-generated method stub
	
			
				try {
					JSONObject jobj=new JSONObject(res);
					String s1= jobj.getString("result");
					if(s1.equalsIgnoreCase("true"))
					{
						Toast.makeText(addemployee.this,"added suceful",Toast.LENGTH_LONG ).show();
					}
					else
					{
					Toast.makeText(addemployee.this,"user registered already",Toast.LENGTH_LONG ).show();
					}
				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Log.i("Tag", "*******"+res);

			  		

				
		
		
		super.onPostExecute(result);
		}

}
	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
	
  		new empadd().execute();
		
	}
	
}
